package com.example.barcodemarket1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import com.google.firebase.storage.StorageReference;

import java.io.ByteArrayOutputStream;
import java.util.Map;


public class MainActivity extends AppCompatActivity {
    private DatabaseReference databaseReference;
    private EditText editTextnamabarang;
    private EditText editTextAmount;
    private ImageView ImageViewBarcode;
    private Button btnInsertData;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextnamabarang=(EditText) findViewById(R.id.editTextnamabarang);
        editTextAmount=(EditText) findViewById(R.id.editTextAmount);
        ImageViewBarcode=(ImageView)findViewById(R.id.ImageViewBarcode);
        btnInsertData=(Button)findViewById(R.id.btnInsertData);


        databaseReference = FirebaseDatabase.getInstance().getReference();
        storageRef =storage.getReferencefromUrl("gs://test-9ae8a.appspot.com/");
        databaseReference.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Map<String, Object> updatedBarcode = (Map<String, Object>) dataSnapshot.getValue();
                Log.i("MainActivity", "updatebarcode=" + updatedBarcode.toString());
            }
            @Override
                public void onCancelled(DatabaseError databaseError){
                Log.i("MainActivity","onCancelled");
        }
        });
    }
    public void handleChooseImage(View view){
        Intent pickerPhotoIntent = new Intent(Intent.ACTION_PICK,android.provider. MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickerPhotoIntent,1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent){
        super.onActivityResult(requestCode,resultCode,imageReturnedIntent);
        switch (requestCode){
            case 0:
                if(requestCode == RESULT_OK){
                    Log.i("MainActivity","case 0");
                }
                break;
            case 1:
                if(resultCode == RESULT_OK){
                    Uri SelectedImage=imageReturnedIntent.getData();
                    Log.i("Mainactiviy","Selectd Image ="+SelectedImage);
                    this.ImageViewBarcode.setImageURI(SelectedImage);
                    this.uploadImageToFirebase();
                }
                break;
        }
    }
    private void uploadImageToFirebase(){
        this.ImageViewBarcode.setDrawingCacheEnabled(true);
        this.ImageViewBarcode.buildDrawingCache();
        Bitmap bitmap = this.ImageViewBarcode.getDrawingCache();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] data = baos.toByteArray();
        StorageReference mountainsRef = storageRef.child("Myimagename.jpg");
        UploadTask uploadTask = mountainsRef.putBytes(data);

        uploadTask.addOnFailureListener(new OnFailureListener(){
            @Override
            public void onFailure(@NonNull Exception exception){
                Log.i("MainActivity","Upload Failed");
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>(){
            @Override
            public void onSucces(UploadTask.TaskSnapshot taskSnapshot){
                Uri downloadUrl = taskSnapshot.getDownloadUrl();
                Log.i("MainAcivity","Upload succesfull, downloadUrl="+downloadUrl);
            }
        });

    }


}
